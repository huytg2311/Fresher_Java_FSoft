package com.example.pa101.service;

public interface ILoginService {

    boolean loginAction(String username, String password);

}
