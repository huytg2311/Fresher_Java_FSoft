package com.example.pa101.repository;

public interface ILoginRepository {

    boolean loginAction(String username, String password);
}
