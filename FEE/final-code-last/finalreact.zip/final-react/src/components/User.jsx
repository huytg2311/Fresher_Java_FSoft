import { BiEdit } from 'react-icons/bi'
import { TiDeleteOutline, TiTick } from 'react-icons/ti'
export const User = ({ item, index, onUpdateData }) => {
    return (
        <>
            <tr>
                <th scope="row">{index + 1}</th>
                <td>
                    {item.username}
                </td>
                <td>
                    {
                        (item.status === 'notactive') ? <label className='text-secondary'>Not active</label> : <label>Active</label>
                    }
                </td>
                <td>
                    {item.email}
                </td>
                <td>
                    <button className="btn btn-primary" onClick={() => { onUpdateData(item) }}><BiEdit></BiEdit></button>
                </td>
            </tr>
        </>
    )
}